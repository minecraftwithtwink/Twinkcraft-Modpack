# TAA Project
This shaderpack is a lightweight vanilla renderer with TAA. It's compatible with OptiFine and Iris.
Hardfork of VanillAA.

## Credits
* 1Xayd1 Recomposed TAA Project
* Vanilla rendering recreation from [XorDevs-Default-Shaderpack](https://github.com/XorDev/XorDevs-Default-Shaderpack)
* TAA implementation from [BSL](https://bitslablab.com/bslshaders/)
* FidelityFX CAS from [AMD](https://github.com/GPUOpen-Effects/FidelityFX-CAS), fragment shader version from [vkBasalt](https://github.com/DadSchoorse/vkBasalt)