/function xaero:silent/nominimap
/function xaero:silent/xaerowmnetherisfair