scoreboard objectives add ls_defaults_storage dummy

execute unless score defaults_set ls_defaults_storage matches 1 run function ls_defaults:defaults/vanilla_refresh
gamerule keepInventory true


scoreboard players set defaults_set ls_defaults_storage 1